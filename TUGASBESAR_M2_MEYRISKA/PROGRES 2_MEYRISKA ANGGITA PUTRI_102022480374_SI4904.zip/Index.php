<?php

    $nama = "";
    $nik = "";
    $tanggal_lahir = "";
    $jenis_kelamin = "";
    $nomor_hp = "";
    $nomor_rekam_medis = "";
    $alamat = "";
    $nama_kontak = "";
    $nomor_kontak = "";

    $namaErr = "";
    $nikErr = "";
    $tanggal_lahirErr = "";
    $jenis_kelaminErr = "";
    $nomor_hpErr = "";
    $nomor_rekam_medisErr = "";
    $alamatErr = "";
    $nama_kontakErr = "";
    $nomor_kontakErr = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // validasi nama
    $nama = trim($_POST["nama"]);
    if (empty($nama)) {
        $namaErr = "Nama wajib diisi";
    }

    // validasi NIK
    $nik = trim($_POST["nik"]);
    if (empty($nik)) {
        $nikErr = "NIK wajib diisi";
    }

    // validasi tanggal lahir
    $tanggal_lahir = trim($_POST["tanggal_lahir"]);
    if (empty($tanggal_lahir)) {
        $tanggal_lahirErr = "Tanggal Lahir wajib diisi";
    }

    // validasi jenis kelamin
    $jenis_kelamin = trim($_POST["jenis_kelamin"]);
    if (empty($jenis_kelamin)) {
        $jenis_kelaminErr = "Jenis Kelamin wajib diisi";
    }

    // validasi nomor HP
    $nomor_hp = trim($_POST["nomor_hp"]);
    if (empty($nomor_hp)) {
        $nomor_hpErr = "Nomor HP wajib diisi";
    }

    // validasi nomor rekam medis
    $nomor_rekam_medis = trim($_POST["nomor_rekam_medis"]);
    if (empty($nomor_rekam_medis)) {
        $nomor_rekam_medisErr = "Nomor Rekam Medis wajib diisi";
    }

    // validasi alamat
    $alamat = trim($_POST["alamat"]);
    if (empty($alamat)) {
        $alamatErr = "Alamat wajib diisi";
    }

    // validasi nama kontak
    $nama_kontak = trim($_POST["nama_kontak"]);
    if (empty($nama_kontak)) {
        $nama_kontakErr = "Nama Kontak wajib diisi";
    }

    // validasi nomor kontak
    $nomor_kontak = trim($_POST["nomor_kontak"]);
    if (empty($nomor_kontak)) {
        $nomor_kontakErr = "Nomor Kontak wajib diisi";
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manajemen Pasien</title>

    <link rel="stylesheet" href="display.css">

</head>

<body>

    <h1>Sistem Informasi Klinik Rawat Jalan</h1>

    <h2>Form Input Data Pasien</h2>

    <form method="POST" action="tampilan.php" target="_blank">

        <h3>1. Profil Pasien</h3>

        <label>Nama Lengkap Pasien:</label>
        <input type="text" name="nama">

        <span class="error">
            <?php echo $namaErr ? "* $namaErr" : ""; ?>
        </span>

        <br><br>


        <label>NIK:</label>
        <input type="text" name="nik">

        <span class="error">
            <?php echo $nikErr ? "* $nikErr" : ""; ?>
        </span>

        <br><br>


        <label>Tanggal Lahir:</label>
        <input type="text" name="tanggal_lahir">

        <span class="error">
            <?php echo $tanggal_lahirErr ? "* $tanggal_lahirErr" : ""; ?>
        </span>

        <br><br>


        <label>Jenis Kelamin:</label>
        <input type="text" name="jenis_kelamin">

        <span class="error">
            <?php echo $jenis_kelaminErr ? "* $jenis_kelaminErr" : ""; ?>
        </span>

        <br><br>


        <label>Nomor HP:</label>
        <input type="tel" name="nomor_hp">

        <span class="error">
            <?php echo $nomor_hpErr ? "* $nomor_hpErr" : ""; ?>
        </span>

        <br><br>


        <h3>2. Nomor Rekam Medis Dasar</h3>

        <label>Nomor Rekam Medis:</label>
        <input type="text" name="nomor_rekam_medis">

        <span class="error">
            <?php echo $nomor_rekam_medisErr ? "* $nomor_rekam_medisErr" : ""; ?>
        </span>

        <br><br>


        <h3>3. Domisili Pasien</h3>

        <label>Alamat / Domisili:</label>

        <br>

        <textarea name="alamat" rows="4" cols="40"></textarea>

        <span class="error">
            <?php echo $alamatErr ? "* $alamatErr" : ""; ?>
        </span>

        <br><br>


        <h3>4. Kontak Darurat</h3>

        <label>Nama Kontak Darurat:</label>
        <input type="text" name="nama_kontak">

        <span class="error">
            <?php echo $nama_kontakErr ? "* $nama_kontakErr" : ""; ?>
        </span>

        <br><br>


        <label>Nomor Kontak Darurat:</label>
        <input type="tel" name="nomor_kontak">

        <span class="error">
            <?php echo $nomor_kontakErr ? "* $nomor_kontakErr" : ""; ?>
        </span>

        <br><br>


        <button type="submit">Simpan</button>

    </form>

    <?php

    if (
        $_SERVER["REQUEST_METHOD"] == "POST" &&
        empty($namaErr) &&
        empty($nikErr) &&
        empty($tanggal_lahirErr) &&
        empty($jenis_kelaminErr) &&
        empty($nomor_hpErr) &&
        empty($nomor_rekam_medisErr) &&
        empty($alamatErr) &&
        empty($nama_kontakErr) &&
        empty($nomor_kontakErr)
    ) {

    ?>

        <h2>Data Pasien</h2>

        <table border="1" cellpadding="8" cellspacing="0">

            <tr>

                <th>No</th>

                <th>Nama</th>

                <th>NIK</th>

                <th>Tanggal Lahir</th>

                <th>Jenis Kelamin</th>

                <th>Nomor HP</th>

                <th>Nomor Rekam Medis</th>

                <th>Alamat</th>

                <th>Kontak Darurat</th>

                <th>Nomor Kontak</th>

            </tr>


            <tr>

                <td>1</td>

                <td><?php echo $nama; ?></td>

                <td><?php echo $nik; ?></td>

                <td><?php echo $tanggal_lahir; ?></td>

                <td><?php echo $jenis_kelamin; ?></td>

                <td><?php echo $nomor_hp; ?></td>

                <td><?php echo $nomor_rekam_medis; ?></td>

                <td><?php echo $alamat; ?></td>

                <td><?php echo $nama_kontak; ?></td>

                <td><?php echo $nomor_kontak; ?></td>

            </tr>

        </table>

    <?php

    }

    ?>

</body>

</html>